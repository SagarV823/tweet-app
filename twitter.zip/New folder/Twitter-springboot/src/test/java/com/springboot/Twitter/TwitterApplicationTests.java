package com.springboot.Twitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
