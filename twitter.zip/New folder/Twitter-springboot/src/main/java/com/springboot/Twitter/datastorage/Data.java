package com.springboot.Twitter.datastorage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.springboot.Twitter.beans.Comment;
import com.springboot.Twitter.beans.Tweet;
import com.springboot.Twitter.beans.User;

public class Data {

	public ArrayList<User> allUsers() {
		ArrayList<User> users = new ArrayList<User>();
		users.add(new User("Sagar", "vermasagar823@gmail.com", "1234", "7009508776", "Verma", "SagarV823"));
		users.add(new User("Rahul", "rahul@gmail.com", "1234", "7009508776", "Sharma", "mukul23"));
		users.add(new User("Rushil", "rushil@gmail.com", "1234", "7009508776", "Jain", "rush44"));
		users.add(new User("Ranjeet", "ranjeet@gmail.com", "1234", "7009508776", "Agarwal", "raj1"));
		users.add(new User("Mukul", "mukul@gmail.com", "1234", "7009508776", "Sharma", "muk23"));
		users.add(new User("Ashwin", "ashwin@gmail.com", "1234", "7009508776", "Sundar", "ash823"));
		users.add(new User("Siddhart", "mukul@gmail.com", "1234", "7009508776", "Jain", "sdj23"));
		users.add(new User("Ashish", "ashish@gmail.com", "1234", "7009508776", "Ghalawat", "ashish823"));
		return users;
	}

	public ArrayList<Tweet> myTweets(){
		ArrayList<Tweet> tweets=new ArrayList<Tweet>();
		
		Comment com1=new Comment("Rajeev", 15, "Pro is a better deal and has 64MP quad camera");
		Comment com2=new Comment("Mukul Sharma", 12, "WonderFull phone");
		List<Comment> comments1 = new ArrayList<Comment>(Arrays.asList(com1,com2));
		tweets.add(new Tweet(1,"Sagar Verma",101,"vermasagar823@gmail.com","Redmi Note 10 Pro!",230,comments1));
		
		
		Comment com3=new Comment("Rahul", 15, "Pro is not a better deal and has 64MP quad camera");
		Comment com4=new Comment("Mukund", 17, "Pro Max camera is wonderfull!");
		List<Comment> comments2 = new ArrayList<Comment>(Arrays.asList(com3,com4));
		tweets.add(new Tweet(2,"Sagar Verma",101,"vermasagar823@gmail.com","Tweet number 2",130,comments2));
		
		Comment com5=new Comment("Rohan", 18, "Rocket Science");
		Comment com6=new Comment("Mukul Sharma", 12, "WonderFull phone");
		Comment com7=new Comment("Mukund", 17, "Pro Max camera is wonderfull!");
		List<Comment> comments3 = new ArrayList<Comment>(Arrays.asList(com5,com6,com7));
		tweets.add(new Tweet(3,"Sagar Verma",101,"vermasagar823@gmail.com","Tweet number 3",201,comments3));
		
		
		Comment com8=new Comment("Deerpal", 19, "Apple apple apple apple");
		List<Comment> comments4 = new ArrayList<Comment>(Arrays.asList(com8));
		tweets.add(new Tweet(4,"Sagar Verma",101,"vermasagar823@gmail.com","Tweet number 4",46,comments4));
		
		
		return tweets;
		
	}
	
	public ArrayList<Tweet> allTweets(){
		ArrayList<Tweet> tweets=new ArrayList<Tweet>();

		Comment com1=new Comment("Rajeev", 15, "Pro is a better deal and has 64MP quad camera");
		Comment com2=new Comment("Mukul Sharma", 12, "WonderFull phone");
		Comment com3=new Comment("Mukund", 16, "Pro Max camera is wonderfull!");
		List<Comment> comments1 = new ArrayList<Comment>(Arrays.asList(com1,com2,com3));
		tweets.add(new Tweet(6, "Deerpal", 728, "deerpal@gmail.com", "Redmi Note 10 Pro!", 230,comments1));
		
		Comment com4=new Comment("Mukul Sharma", 12, "enjoyed a lot");
		List<Comment> comments2 = new ArrayList<Comment>(Arrays.asList(com4));
		tweets.add(new Tweet(7, "Rohit Sharma", 103, "rohitsharma@gmail.com", "What a great day it was!", 156,comments2));
		
		Comment com5=new Comment("Mukul Sharma", 12, "enjoyed a lot");
		Comment com6=new Comment("Sagar Verma", 101, "Indeed it was");
		Comment com7=new Comment("Mukund", 17, "Pro Max camera is wonderfull!");
		List<Comment> comments3 = new ArrayList<Comment>(Arrays.asList(com5,com6,com7));
		tweets.add(new Tweet(8, "Rahul Sharma", 104, "rahul@gmail.com", "What a great movie it was!", 156,comments3));
		
		Comment com8=new Comment("Mukul Sharma", 12, "enjoyed a lot");
		Comment com9=new Comment("Ashwin Sundar", 101, "it was mad!");
		List<Comment> comments4 = new ArrayList<Comment>(Arrays.asList(com8));
		tweets.add(new Tweet(9, "Rahul Sharma", 104, "rahul@gmail.com", "Tweet number 2", 16,comments4));
		
		return tweets;
		
	}
}
