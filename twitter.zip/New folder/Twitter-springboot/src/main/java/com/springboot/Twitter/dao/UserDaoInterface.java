package com.springboot.Twitter.dao;

import com.springboot.Twitter.beans.User;

public interface UserDaoInterface {
	
	public void registerUser(User user);
	public User authenticate(String email,String password);

}
