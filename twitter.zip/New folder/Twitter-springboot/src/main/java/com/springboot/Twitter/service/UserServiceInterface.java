package com.springboot.Twitter.service;

import java.util.List;

import com.springboot.Twitter.beans.User;

public interface UserServiceInterface {

	public void registerUser(User user);
	public User authenticate(String email,String password);
	public List<User> allUsers();
	
}
