package com.springboot.Twitter.service;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.Twitter.beans.Comment;
import com.springboot.Twitter.beans.Tweet;
import com.springboot.Twitter.dao.TweetDaoImpl;

@Service
public class TweetServiceImpl implements TweetServiceInterface{

	@Autowired
	public TweetDaoImpl tweetDaoImpl;
	
	public ArrayList<Tweet> getTweets(String type) {
		return tweetDaoImpl.allTweets(type);
	}
	
	public String postTweet(Tweet tweet) {
		return tweetDaoImpl.postTweet(tweet);
	}
	
	public Tweet addComment(Comment comment,String tweettype,int tweetid){
		return tweetDaoImpl.addComment(comment,tweettype,tweetid);
	}

}
