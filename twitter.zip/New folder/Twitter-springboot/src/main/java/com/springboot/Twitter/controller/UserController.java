package com.springboot.Twitter.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.Twitter.beans.User;
import com.springboot.Twitter.service.UserServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	public UserServiceImpl userServiceImpl;

	@PostMapping("/api/v1.0/twitter/register")
	public String registerUser(@RequestBody() User user) {
		userServiceImpl.registerUser(user);
		return user.firstName + " " + user.lastName;
	}

	@GetMapping("/api/v1.0/twitter/login")
	public User login(@RequestParam("email") String email, @RequestParam("password") String password) {
		User user = new User();
		user = userServiceImpl.authenticate(email, password);
		return user;
	}

	@GetMapping("/api/v1.0/twitter/users/all")
	public List<User> getAllUsers() {
		return userServiceImpl.allUsers();
	}

}
