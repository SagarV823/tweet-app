package com.springboot.Twitter.dao;

import java.util.ArrayList;
import com.springboot.Twitter.beans.Tweet;

public interface TweetDaoInterface {

	public ArrayList<Tweet> allTweets(String type);
	
}
