package com.springboot.Twitter.service;

import java.util.ArrayList;
import com.springboot.Twitter.beans.Tweet;

public interface TweetServiceInterface {

	public ArrayList<Tweet> getTweets(String type);
}
