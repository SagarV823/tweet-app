package com.springboot.Twitter.beans;

public class Comment {
	
	public String commentUsername;
	public int commentUserId; 
	public String commentMessage;
	
	public Comment() {
		super();
	}
	public Comment(String commentUsername, int commentUserId, String commentMessage) {
		super();
		this.commentUsername = commentUsername;
		this.commentUserId = commentUserId;
		this.commentMessage = commentMessage;
	}
	public String getCommentUsername() {
		return commentUsername;
	}
	public void setCommentUsername(String commentUsername) {
		this.commentUsername = commentUsername;
	}
	public int getCommentUserId() {
		return commentUserId;
	}
	public void setCommentUserId(int commentUserId) {
		this.commentUserId = commentUserId;
	}
	public String getCommentMessage() {
		return commentMessage;
	}
	public void setCommentMessage(String commentMessage) {
		this.commentMessage = commentMessage;
	} 
	
	
}
