import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { AvatarComponent } from './home/avatar/avatar.component';
import { TweetlistComponent } from './home/tweetlist/tweetlist.component';
import { TweetdetailsComponent } from './home/tweetdetails/tweetdetails.component';
import { TweetComponent } from './home/tweetlist/tweet/tweet.component';
import { TweetstartComponent } from './home/tweetstart/tweetstart.component';
import { UsersComponent } from './users/users.component';
import { UsersstartComponent } from './users/usersstart/usersstart.component';
import { UserslistComponent } from './users/userslist/userslist.component';
import { UserprofileComponent } from './users/userprofile/userprofile.component';
import { UserComponent } from './users/userslist/user/user.component';
import { Tweetdetails2Component } from './home/tweetdetails2/tweetdetails2.component';
import { TestingComponent } from './testing/testing.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    HomeComponent,
    AvatarComponent,
    TweetlistComponent,
    TweetdetailsComponent,
    TweetComponent,
    TweetstartComponent,
    UsersComponent,
    UsersstartComponent,
    UserslistComponent,
    UserprofileComponent,
    UserComponent,
    Tweetdetails2Component,
    TestingComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
