import { Component, ElementRef, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Tweet } from 'src/app/models/tweet.model';
import { UserComment } from 'src/app/models/usercomment.modal';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-tweetdetails',
  templateUrl: './tweetdetails.component.html',
  styleUrls: ['./tweetdetails.component.css']
})
export class TweetdetailsComponent implements OnInit {

  constructor(private route: ActivatedRoute, private dataService: DataService) { }

  tweet: Tweet;
  tweetid: number;
  tindex:number;
  totalcoms: number;
  tweettype:string;

  ngOnInit(): void {
    this.route.params.subscribe((params: Params) => {
      this.tindex = params['id'];
      console.log(this.tindex, "tweet id");
      

      this.dataService.tweettype.subscribe(type => {
        this.tweettype=type;
        if (this.tweettype === "MyTweets") {
          this.tweet = this.dataService.mytweets[this.tindex];
          this.tweetid=this.tweet.tweetid;
        }
        if (this.tweettype === "AllTweets") {
          this.tweet = this.dataService.alltweets[this.tindex];
          this.tweetid=this.tweet.tweetid;
        }
        this.totalcoms = this.tweet.comments.length;
      });
    });
  }

  onCommentButton(input:HTMLInputElement){
    console.log(input.value);
    this.dataService.addComment(this.tweettype,this.tweetid,input.value);
  }
}
