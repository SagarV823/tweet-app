import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TweetdetailsComponent } from './tweetdetails.component';

describe('TweetdetailsComponent', () => {
  let component: TweetdetailsComponent;
  let fixture: ComponentFixture<TweetdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TweetdetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TweetdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
