import { Component, Input, OnInit } from '@angular/core';
import { Tweet } from 'src/app/models/tweet.model';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-tweetlist',
  templateUrl: './tweetlist.component.html',
  styleUrls: ['./tweetlist.component.css']
})
export class TweetlistComponent implements OnInit {

  @Input() specifictweets:Tweet[]=[];
  tweets:Tweet[];
  constructor(private dataService:DataService) { }

  ngOnInit(): void {

    this.dataService.tweettype.subscribe(type=>{
      if(type==="MyTweets"){
        this.tweets=this.dataService.mytweets;
      }
      if(type==="AllTweets"){
        this.tweets=this.dataService.alltweets;
      }
    });

    this.tweets=this.specifictweets;
  }

}
