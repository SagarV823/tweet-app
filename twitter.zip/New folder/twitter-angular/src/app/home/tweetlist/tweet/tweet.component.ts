import { Component, Input, OnInit } from '@angular/core';
import { Tweet } from 'src/app/models/tweet.model';

@Component({
  selector: 'app-tweet',
  templateUrl: './tweet.component.html',
  styleUrls: ['./tweet.component.css']
})
export class TweetComponent implements OnInit {

  
  @Input() tweet:Tweet;
  @Input() index: number;

  comments=[];
  totalcomms:number;

  constructor() { }

  ngOnInit(): void {
    this.comments=this.tweet.comments;
    this.totalcomms=this.comments.length;
    console.log(this.totalcomms);
  }

}
