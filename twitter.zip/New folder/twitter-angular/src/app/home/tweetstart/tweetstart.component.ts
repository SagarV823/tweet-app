import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tweetstart',
  templateUrl: './tweetstart.component.html',
  styleUrls: ['./tweetstart.component.css']
})
export class TweetstartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
