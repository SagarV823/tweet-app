import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TweetstartComponent } from './tweetstart.component';

describe('TweetstartComponent', () => {
  let component: TweetstartComponent;
  let fixture: ComponentFixture<TweetstartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TweetstartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TweetstartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
