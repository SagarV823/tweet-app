import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Tweet } from 'src/app/models/tweet.model';
import { UserComment } from 'src/app/models/usercomment.modal';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-tweetdetails2',
  templateUrl: './tweetdetails2.component.html',
  styleUrls: ['./tweetdetails2.component.css']
})
export class Tweetdetails2Component implements OnInit {


  constructor(private route: ActivatedRoute, private dataService: DataService, private authService: AuthService,private router:Router) { }

  tweet: Tweet;
  tweetindex: number;
  tweetid: number;
  coms: UserComment[];
  totalcoms: number;
  useremailid: string;
  tweets: Tweet[];

  ngOnInit(): void {
    this.route.params.subscribe((params: Params) => {
      this.tweetindex = params['tid'];
      console.log(this.tweetindex);
      this.tweet = this.dataService.getTweet(this.tweetindex);
      this.tweetid = this.tweet.tweetid;
      console.log("tweetid", this.tweetid)
      this.totalcoms = this.tweet.comments.length;
      console.log(this.tweet);
    });
  }
  onCommentButton(input: HTMLInputElement) {
    console.log(input.value);
    this.dataService.addComment("AllTweets",this.tweetid, input.value);
    this.router.navigate(['../', this.tweetindex], {relativeTo: this.route});
  }
}
