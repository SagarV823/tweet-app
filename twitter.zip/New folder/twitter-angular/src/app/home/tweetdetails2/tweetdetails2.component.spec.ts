import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Tweetdetails2Component } from './tweetdetails2.component';

describe('Tweetdetails2Component', () => {
  let component: Tweetdetails2Component;
  let fixture: ComponentFixture<Tweetdetails2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Tweetdetails2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Tweetdetails2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
