import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Tweet } from '../models/tweet.model';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private dataService:DataService,private router: Router) { }
  
  myname = "Sagar Verma";
  userid=101;
  tweetmessage:string='';
  tweet:Tweet={};
  tweetnumber:number=11;
  ngOnInit(): void {
    this.dataService.tweettype.next("MyTweets");
    console.log(this.router.url,"url");
  }

  onSubmit(tweetForm: NgForm) {
    this.tweetnumber=this.tweetnumber++;
    this.tweetmessage = tweetForm.value.tweet;
    this.tweet=new Tweet(this.tweetnumber,this.myname,this.userid,"vermasagar823@gmail.com",this.tweetmessage,0,[]);
    this.dataService.postNewTweet(this.tweet);
    this.myTweets();
    tweetForm.reset();
    console.log(this.tweetmessage);
  }

  myTweets(){
    this.dataService.setMyTweets();
  }

  newFeeds(){
    this.dataService.setAllTweets();
  }

}
