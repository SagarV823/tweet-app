import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.component.html',
  styleUrls: ['./avatar.component.css']
})
export class AvatarComponent implements OnInit {

  constructor() { }
  @Input() imagepath="https://png.pngtree.com/png-vector/20191116/ourmid/pngtree-businessman-avatar-icon-vector-download-vector-user-icon-avatar-silhouette-social-png-image_1991050.jpg";
  @Input() name="Sagar Verma";

  ngOnInit(): void {
  }

}
