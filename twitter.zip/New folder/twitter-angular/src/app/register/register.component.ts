import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  signupForm: FormGroup;

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.signupForm =new FormGroup({
      firstName: new FormControl(null, Validators.required),
      email: new FormControl(null, Validators.required),
      password: new FormControl(null, [Validators.required, Validators.minLength(6)]),
      contactNumber: new FormControl(null, Validators.required),
      lastName: new FormControl(null, Validators.required),
      loginId: new FormControl(null, Validators.required),
      conPassword: new FormControl(null, [Validators.required, Validators.minLength(6)]),   
    });
  }

  register(){
    this.authService.registerUser(this.signupForm.value);
  }

}
