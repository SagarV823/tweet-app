import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usersstart',
  templateUrl: './usersstart.component.html',
  styleUrls: ['./usersstart.component.css']
})
export class UsersstartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
