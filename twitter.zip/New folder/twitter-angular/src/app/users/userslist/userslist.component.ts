import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { User } from 'src/app/models/user.model';
import { ApiService } from 'src/app/services/api.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-userslist',
  templateUrl: './userslist.component.html',
  styleUrls: ['./userslist.component.css']
})
export class UserslistComponent implements OnInit {

  constructor(private authService: AuthService,private apiService:ApiService) { }

  @Input() users: User[];
  subscription: Subscription;

  ngOnInit(): void {

    // this.apiService.getAllUsers().subscribe((users:User[])=>{
    //   this.authService.setUsers(users);
    // });
    // this.subscription= this.authService.usersChanged.subscribe((users:User[])=>{
    //   this.users=users;
    // })
    // this.users=this.authService.getUsers();
  }
  ngOnDestroy() {
    // this.subscription.unsubscribe();
  }

}
