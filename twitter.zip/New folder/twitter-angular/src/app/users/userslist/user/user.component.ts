import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private router:Router,private route:ActivatedRoute,private dataService:DataService,private authService:AuthService) { }

  @Input() index:number;
  @Input() user:User;

  ngOnInit(): void {
  }
  Go(){
    this.authService.selectedUser.next(this.user.email);
    this.router.navigate([this.user.email], {relativeTo: this.route});
  }

}
