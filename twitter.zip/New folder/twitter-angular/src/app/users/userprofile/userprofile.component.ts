import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Tweet } from 'src/app/models/tweet.model';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  constructor(private route:ActivatedRoute,private authService:AuthService,private dataService:DataService) { }

  useremailId:string;
  user:User;
  tweets:Tweet[];

  ngOnInit(): void {
    this.route.params.subscribe((params:Params)=>{
      this.useremailId=params['id'];
      this.user=this.authService.getUser(this.useremailId);
      this.tweets=this.dataService.getTweets(this.user.email);
    })
  }

}
