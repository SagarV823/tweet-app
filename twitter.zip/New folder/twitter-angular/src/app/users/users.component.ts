import { Component, OnInit } from '@angular/core';
import { User } from '../models/user.model';
import { ApiService } from '../services/api.service';
import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  name:String
  users:User[];
  constructor(private authService:AuthService,private apiService:ApiService,private dataService:DataService) { }

  ngOnInit(): void {
    this.dataService.setAllTweets();
    this.apiService.getAllUsers().subscribe(users=>{
      this.setUsers(users);
    })
    this.name=this.authService.curuser.firstName+ " " +this.authService.curuser.lastName;
  }
  setUsers(users){
    this.users=users;
    this.authService.setUsers(users);
  }

}
