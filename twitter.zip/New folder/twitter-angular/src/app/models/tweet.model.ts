import { UserComment } from "./usercomment.modal";

export class Tweet{
    tweetid?:number;
    username?:string;
    userId?:number;
    useremail?:string;
    tweetMessage?:string;
    tweetLikes?:number;
    comments?:UserComment[];
    
    constructor(tweetid,username,userId,useremail,tweetMessage,tweetLikes,comments){
        this.tweetid=tweetid;
        this.username=username;
        this.userId=userId;
        this.tweetMessage=tweetMessage;
        this.tweetLikes=tweetLikes;
        this.comments=comments;
        this.useremail=useremail;
    }
}