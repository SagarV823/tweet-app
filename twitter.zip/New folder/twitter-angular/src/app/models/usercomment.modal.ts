export class UserComment{
    commentUsername?:string;
    commentUserId?:number;
    commentMessage?:string;

    constructor(commentUsername:string,commentUserId:number,commentMessage:string){
        this.commentUsername=commentUsername;
        this.commentUserId=commentUserId;
        this.commentMessage=commentMessage;
    }
}