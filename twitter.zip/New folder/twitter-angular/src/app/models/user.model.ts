export class User {

    public firstName: string;
    public email: string;
    public password: string;
    public contactNumber: string;
    public lastName: string;
    public loginId: string;
    public conPassword?: string;

    constructor(firstName: string, email: string,
        password: string, contactNumber: string,
        lastName: string, loginId: string,
        conPassword: string) {

        this.firstName = firstName;
        this.email = email;
        this.password = password;
        this.contactNumber = contactNumber;
        this.lastName = lastName;
        this.loginId = loginId;
        this.conPassword= conPassword;
    }
}