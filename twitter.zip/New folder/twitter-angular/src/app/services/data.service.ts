import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { Tweet } from '../models/tweet.model';
import { User } from '../models/user.model';
import { UserComment } from '../models/usercomment.modal';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  mytweets: Tweet[] = [];
  alltweets: Tweet[] = [];

  tweettype = new BehaviorSubject<string>("AllTweets")
  selUser: string = '';
  curuser: User;

  constructor(private authService: AuthService, private apiService: ApiService) {
  }

  postTweet(tweetmessage: Tweet) {
    this.mytweets.push(tweetmessage);
  }

  setMyTweets() {
    this.apiService.getAllTweets("mytweets").subscribe(tweets => {
      this.mytweets = tweets;
      this.tweettype.next("MyTweets");
    });
  }
  setAllTweets() {
    this.apiService.getAllTweets("alltweets").subscribe(tweets => {
      this.alltweets = tweets;
      this.tweettype.next("AllTweets");
    });
  }

  postNewTweet(tweet: Tweet) {
    this.apiService.newTweet(tweet);
  }

  getTweets(email: string) {
    this.selUser = email;
    const tweets = this.alltweets.filter(tweet => tweet.useremail === email);
    return tweets;
  }

  getTweet(tweetindex: number) {
    const tweets = this.alltweets.filter(tweet => tweet.useremail === this.selUser);
    return tweets[tweetindex];
  }

  addComment(tweettype: string, tweetid: number, comment: string) {
    this.curuser = this.authService.curuser;
    const name = this.curuser.firstName + ' ' + this.curuser.lastName;
    const com = new UserComment(name, 101, comment);
    let tid = tweetid.toString();
    console.log(this.curuser);
    if (tweettype === "MyTweets") {
      this.apiService.addComment("mytweets", tid, com);
      this.setMyTweets();
    }
    else if (tweettype === "AllTweets") {
      this.apiService.addComment("alltweets", tid, com);
    }
  }
  // addComment2(tweetid: number, comment: string) {
  //   this.curuser = this.authService.curuser;
  //   const name = this.curuser.firstName + ' ' + this.curuser.lastName;
  //   const com = new UserComment(name, 101, comment);
  //   const tweetindex = this.alltweets.findIndex(tweet => tweet.tweetid === tweetid);
  //   this.alltweets[tweetindex].comments.push(com);
  //   console.log("tweet index ", tweetindex);
  // }

}
