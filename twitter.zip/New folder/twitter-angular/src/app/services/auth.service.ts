import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Subject } from 'rxjs';
import { timeout } from 'rxjs/operators';
import { User } from '../models/user.model';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  users: User[] = [];

  usersChanged = new Subject<User[]>();
  loggedInUser = new BehaviorSubject<User>(null);
  selectedUser = new Subject<string>();

  curuser: User;

  constructor(private router: Router, private apiService: ApiService) { }

  registerUser(user: User) {
    this.users.push(user);
    this.apiService.registerUser(user);
    console.log("Registered!", user);
  }

  loginUser(email: string, password: string) {
    this.apiService.login(email, password).subscribe(user => {
      this.loggedInUser.next(user);
      this.curuser = user;
      sessionStorage.setItem("currentuser",JSON.stringify(this.curuser));
      if(user){
        console.log("in service");
        return true;
      }
      return false;
    });
  }
  autoLogin() {
    const user = JSON.parse(sessionStorage.getItem('currentuser'));
    this.curuser = user;
    this.loggedInUser.next(user);
  }

  setUsers(users: User[]) {
    this.users = users;
    this.usersChanged.next(this.users.slice());
  }

  getUsers() {
    return this.users;
  }

  getUser(email: string) {
    return this.users.find(user => user.email === email);
  }

}
