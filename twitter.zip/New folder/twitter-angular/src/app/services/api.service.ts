import { Injectable } from '@angular/core';
import { User } from '../models/user.model';
import { HttpClient } from '@angular/common/http';
import { Tweet } from '../models/tweet.model';
import { UserComment } from '../models/usercomment.modal';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  backendurl = "http://localhost:8081/api/v1.0/twitter";

  registerUser(user: User) {
    this.http.post<User>(
      this.backendurl + '/register', user
    ).subscribe(data => {
      console.log("data ", data);
    })
  }

  login(email: string, password: string) {
    return this.http.get<User>(this.backendurl + '/login', {
      params: {
        email,
        password
      }
    });
  }

  getAllUsers() {
    return this.http.get<User[]>(this.backendurl + '/users/all');
  }

  newTweet(tweet: Tweet) {
    // console.log(tweet.tweetMessage + " " + tweet.useremail);
    this.http.post<Tweet>(
      this.backendurl + '/username/add', tweet, { params: { username: tweet.useremail } }).subscribe(data => {
        console.log("data ", data);
      })
  }

  addComment(tweettype: string, tid: string, comment: UserComment) {
    console.log("com is ", comment)
    this.http.post<UserComment>(
      this.backendurl + '/username/reply', comment, { 
        params: 
        { 
          tweettype,
          tid 
        } 
      }).subscribe(data => {
        console.log("data ", data);
      });
  }

  getAllTweets(type: string) {
    return this.http.get<Tweet[]>(this.backendurl + '/tweets/all', { params: { type } });
  }

}
