import { Component, OnInit } from '@angular/core';
// import * as Chartist from 'svg-chartist';

@Component({
  selector: 'app-testing',
  templateUrl: './testing.component.html',
  styleUrls: ['./testing.component.css']
})
export class TestingComponent implements OnInit {

  constructor() { }

  data1 = {
    labels: ['Apple', 'Blueberry', 'KeyLime'],
    series: [60, 10, 30]
  };

  ngOnInit(): void {
    // new Chartist.Pie('#chart5', this.data1);
  }

}
