import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email = '';
  password = '';
  exist: boolean;
  constructor(private router: Router, private authService: AuthService) { }

  ngOnInit(): void {
  }

  onSubmit(authForm: NgForm) {
    this.email = authForm.value.email;
    this.password = authForm.value.password;
    const result = this.authService.loginUser(this.email, this.password);
    console.log(result);
    if (true) {
      this.exist = true;
      this.router.navigate(['home']);
    }
    else {
      this.exist = false;
      authForm.reset();
    }
  }
}
