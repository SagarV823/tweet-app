import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { TweetdetailsComponent } from './home/tweetdetails/tweetdetails.component';
import { Tweetdetails2Component } from './home/tweetdetails2/tweetdetails2.component';
import { TweetstartComponent } from './home/tweetstart/tweetstart.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { TestingComponent } from './testing/testing.component';
import { UserprofileComponent } from './users/userprofile/userprofile.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: "login", component: LoginComponent },
  { path: "testing", component: TestingComponent },
  { path: "register", component: RegisterComponent },
  {
    path: "home", component: HomeComponent,
    children: [
      { path: '', component: TweetstartComponent },
      {
        path: ':id',
        component: TweetdetailsComponent
      }
    ]
  },
  { path: "users", component: UsersComponent },

  {
    path: "users/:id", component: UserprofileComponent, children: [
      {
        path: ':tid',
        component: Tweetdetails2Component
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
